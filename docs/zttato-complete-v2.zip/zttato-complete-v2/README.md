# zTTato Complete Package v2
**Generated:** 2026-09-26

Everything discussed and produced for [cvsz/zttato-platform](https://github.com/cvsz/zttato-platform).

## Contents

```
zttato-complete-v2/
├── README.md
├── dashboard/
│   └── web/
│       ├── dashboard.html          ← UI redesign (pre-i18n baseline)
│       ├── dashboard.js
│       └── dashboard-styles.css
├── docs/
│   ├── AI_MASTER_PRODUCTION_PROMPT.md   ← Original production master prompt
│   └── AI_MASTER_UPGRADE_PROMPT.md      ← New upgrade-focused master prompt
├── guides/
│   ├── 01-webpack-bundling.md
│   ├── 02-module-federation.md
│   ├── 03-native-federation.md
│   ├── 04-single-spa.md
│   └── 05-comparisons.md
└── strategy/
    ├── 01-creator-to-affiliate-framework.md
    └── 02-current-state-review.md
```

## How to use

### For OpenCode / AI agents
1. Place `docs/AI_MASTER_UPGRADE_PROMPT.md` into the repo `docs/` folder
2. Start session with:  
   `Read and strictly follow docs/AI_MASTER_UPGRADE_PROMPT.md and AGENTS.md`

### For dashboard redesign
- The dashboard files are a visual/UX upgrade based on the pre-i18n version
- Before applying, merge carefully with current HEAD so all `data-i18n` attributes and `i18n.t()` calls are preserved

### Strategy
- Read `strategy/01-creator-to-affiliate-framework.md` for the recommended sequencing
- Read `strategy/02-current-state-review.md` for the latest assessment

## Key verified TikTok properties (as of 2026-09-26)

- https://zttato.zeaz.dev/tiktok/
- https://zttato.zeaz.dev/tiktok/uploading/
- https://zttato.zeaz.dev/tiktok/video/
- Domain: zeaz.dev
- Domain: zttato.zeaz.dev

## Strategy summary

> Make zTTato the most reliable, multi-language, consent-respecting creator publishing tool first.  
> Only then grow it into a full Affiliate platform on top of that trusted foundation.
