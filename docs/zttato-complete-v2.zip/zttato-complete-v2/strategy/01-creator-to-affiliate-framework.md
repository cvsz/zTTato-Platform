# Decision & Sequencing Framework
## Creator Tool → Full Affiliate Platform

### Core Principle

> **Ship a production-grade Creator tool first.  
> Expand into Affiliate only after the Creator foundation is stable, evidenced, and generating real usage/learning.**

Never let the Affiliate ambition block or dilute the Creator product.

---

### Two Distinct Products

| Dimension              | Phase 1: Creator Tool                              | Phase 2: Affiliate Platform                          |
|------------------------|----------------------------------------------------|------------------------------------------------------|
| Primary user           | Individual creators                                | Creators + merchants / brands / operators            |
| Core job               | Publish content to TikTok (later other platforms)  | Discover products → create content → track commissions |
| Main value             | Speed, reliability, consent, multi-language        | Product catalog, offers, links, attribution, analytics |
| TikTok role            | Primary distribution channel                       | One of several distribution channels                 |
| Success metric         | Successful publishes, low error rate, retention    | Tracked conversions, GMV influenced, active campaigns |
| Architecture focus     | Distribution + Media + Consent                     | Commerce → Affiliate Core → Content → Distribution   |

---

### Phase Gates

#### Phase 1 Exit Criteria (Creator Tool is “done enough”)

- [ ] All controllable Production Gates are PASS or clearly BLOCKED_EXTERNAL
- [ ] Real TikTok Sandbox E2E evidence exists for every requested capability
- [ ] Dashboard is polished and fully internationalized (6 languages)
- [ ] Photo + Video publish flows are stable and idempotent
- [ ] Media cleanup / retention is implemented
- [ ] Basic observability is live
- [ ] At least one real creator (or internal dogfood) has used it successfully
- [ ] No major open security or data-loss risks

#### Phase 2 Entry Criteria

- Phase 1 exit criteria largely met
- Clear decision that the business wants the Affiliate direction
- Capacity available without starving Creator maintenance

---

### Sequencing Roadmap

```
NOW                    NEAR TERM                  LATER
──────────────────────────────────────────────────────────────
Creator Tool           Creator Hardening          Affiliate Platform
(current)              + Multi-platform stubs     (full vision)
```

**Stage A — Creator Excellence (Current Focus)**
- Close operational & evidence gaps
- Polish dashboard (keep full i18n)
- Stabilize photo + video posting
- Media retention + basic monitoring
- Keep architecture boundaries clean

**Stage B — Creator Expansion (Optional but valuable)**
- Add second distribution provider (YouTube or Instagram) behind the same publishing contract
- Proves the “Distribution Providers” layer is real

**Stage C — Affiliate Foundation**
- Introduce internal Product / Offer / AffiliateLink models
- Keep them completely free of TikTok-specific code
- Simple manual or CSV product import first
- Link generation + basic click tracking

**Stage D — Affiliate Growth**
- Commerce adapters (Shopee, TikTok Shop, etc.)
- Campaigns + content association
- Conversion ingestion + analytics
- Creator-facing affiliate dashboard

---

### Architecture Rules During Transition

1. TikTok remains only a Distribution adapter
2. Affiliate Core must be able to run without any TikTok credentials
3. Publishing Intent stays provider-neutral
4. New Affiliate features are additive
5. Feature flags / capability detection — hide Affiliate sections until real

---

### Decision Triggers

| Signal | Action |
|--------|--------|
| Creator tool is stable and used | Start Stage B or light Stage C design |
| Business prioritizes commissions / product linking | Accelerate Stage C |
| TikTok production approval blocked long-term | Consider adding another distribution channel first |
| Team capacity is low | Stay in Stage A longer |
| Real creators ask for product linking | Strong signal to enter Stage C |

---

### Anti-Patterns to Avoid

- Building complex product catalogs before the publish flow is excellent
- Mixing TikTok-specific fields into core Product/Offer models
- Claiming “Affiliate Platform” while only Creator features work
- Letting Affiliate scope delay closing Production Gates
- Rewriting the dashboard from scratch instead of evolving it

---

### One-Sentence Strategy

> Make zTTato the most reliable, multi-language, consent-respecting creator publishing tool first.  
> Only then grow it into a full Affiliate platform on top of that trusted foundation.
