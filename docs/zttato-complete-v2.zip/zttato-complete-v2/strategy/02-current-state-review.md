# zTTato Platform — Current State Deep Review
**Date:** 2026-09-26

## Snapshot

| Layer | Reality |
|-------|---------|
| Product | First-party TikTok Creator tool (Login Kit + Content Posting API) |
| Domain | zttato.zeaz.dev (verified) + parent zeaz.dev |
| Verified TikTok properties | 3 URL prefixes + 2 domains |
| Core flow | Connect → Upload → Draft/Direct → Consent → Publish |
| i18n | 6 languages live (en, th, zh, ja, ko, vi) |
| Architecture intent | Commerce → Affiliate Core → Content/Media → Distribution |
| Code reality | Heavily TikTok-creator focused; Affiliate Core mostly aspirational |
| Status claim | Explicitly not production-ready (correct) |

## Verified TikTok Properties (Production)

- https://zttato.zeaz.dev/tiktok/          (URL prefix)
- https://zttato.zeaz.dev/tiktok/uploading/ (URL prefix)
- https://zttato.zeaz.dev/tiktok/video/     (URL prefix)
- zeaz.dev                                 (Domain)
- zttato.zeaz.dev                          (Domain)

These close the domain/URL verification gate. They do **not** close production approval.

## Strengths

- Clear architectural boundaries and documentation discipline
- Evidence-based production gates
- Official TikTok APIs only
- Server-side encrypted tokens, CSRF, idempotency
- Fresh i18n support
- Legal pages, review walkthrough, Docker/CI baseline

## Gaps

1. Dashboard UX functional but basic
2. Affiliate Core still largely aspirational
3. Many production gates open or BLOCKED_EXTERNAL
4. i18n needs hardening and full coverage checks
5. Photo post support needs full test + evidence coverage
6. No background jobs / media retention cleanup yet
7. Limited observability

## Strategic Position

zTTato is a well-disciplined TikTok Creator MVP with strong architectural *intent* to become a multi-provider Affiliate + Content platform.

Two futures:
- **Path A**: Excellent multi-platform creator publishing tool
- **Path B**: Full Affiliate platform

Current code is closer to Path A; documentation pushes Path B. A conscious decision is required.

## Highest-Leverage Next Moves

1. Close controllable production gates + record verified properties as evidence
2. Harden i18n + polish dashboard (keep all translations)
3. Decide Creator-first vs early Affiliate expansion
4. Keep TikTok strictly as a distribution adapter
