# zTTato Platform — AI Master Upgrade Prompt (Post-i18n / Post-Review Baseline)

> **Canonical upgrade contract for any capable engineering AI working on `cvsz/zttato-platform`.**
>
> Applies to OpenCode, Codex, Claude Code, Gemini CLI, Cursor, Copilot and equivalent agents.
>
> **Baseline date:** 2026-09-26  
> **Current HEAD includes:** i18n (en/th/zh/ja/ko/vi), photo post submission, TikTok review preparation files.
>
> Repository status remains evidence-driven. Never claim TikTok production approval or overall production readiness without verifiable evidence.

## 1. Mission

Upgrade the repository from its **current verified baseline** to the next production-grade increment that can be implemented and objectively verified in the available environment.

Focus areas (in priority order):

1. Harden and complete the newly added i18n system
2. Improve Creator Dashboard UX while preserving all i18n attributes and API contracts
3. Close as many open Production Gates as possible under local/repository control
4. Strengthen Affiliate Core boundaries (even if full commerce adapters are not yet implemented)
5. Add missing operational pieces (cleanup jobs, better observability, media retention)
6. Keep TikTok integration strictly within its distribution boundary

Do engineering work, not proposal-only analysis.

Use:

```text
DISCOVER → MODEL → RISK ASSESS → PLAN → IMPLEMENT → MIGRATE → TEST
→ SECURITY AUDIT → OPERABILITY AUDIT → DOCUMENT → VERIFY → RELEASE GATE
```

If blocked by external approval, credentials, legal review or infrastructure → implement everything possible and record the blocker as `BLOCKED_EXTERNAL`.

Never manufacture success.

---

## 2. Non-negotiable rules

1. Inspect the real repository before changing anything.
2. Treat README, AGENTS.md, source, migrations, tests, CI and docs as evidence.
3. Do not perform a blind rewrite.
4. Preserve working behavior unless a documented security/correctness issue requires change.
5. No production TODO/FIXME, fake success, swallowed exceptions or dead endpoints advertised as working.
6. Never weaken security or tests for a green build.
7. Never commit secrets, tokens, cookies, private keys or credential-bearing URLs.
8. Use official TikTok Login Kit + Content Posting API only.
9. Never implement scraping, password automation, CAPTCHA bypass or anti-detection.
10. Every material change must have tests and documentation appropriate to its risk.
11. Keep changes small enough to review and rollback.
12. Produce objective evidence for every claimed readiness gate.
13. Preserve and extend the existing i18n system (data-i18n attributes, i18n.t(), locale detection, translation files).
14. Any dashboard UI upgrade must remain fully compatible with the 6-language i18n layer.

---

## 3. Current baseline inventory (must re-verify)

Before any upgrade work, re-inventory:

```text
ARCHITECTURE
SERVICES / MODULES (app/, web/, app/i18n/)
DEPENDENCIES
DATA MODEL + MIGRATIONS
AUTHENTICATION / OAUTH / TOKEN ENCRYPTION
AUTHORIZATION / TENANCY
I18N SYSTEM (new)
DASHBOARD (HTML/JS/CSS + i18n)
TIKTOK INTEGRATION (Login Kit, Content Posting, photo post)
MEDIA HANDLING
JOBS / IDEMPOTENCY
SECURITY CONTROLS
CI/CD
LEGAL PAGES
PRODUCTION GATES STATUS
KNOWN BLOCKERS
TIKTOK VERIFIED PROPERTIES
```

Record the exact commit SHA you start from.

---

## 4. Priority upgrade tracks

### Track A — i18n Hardening (High priority)
- Verify all dashboard strings are covered by translation files
- Ensure locale detection (Accept-Language, cookie, query) works correctly
- Add missing keys if any UI text is still hardcoded
- Test fallback to English
- Document how to add a new language
- Keep `web/i18n.js` and server routes in sync

### Track B — Dashboard UX Upgrade (High priority)
- Improve visual hierarchy, spacing, status feedback and mobile experience
- Preserve every `data-i18n` attribute and all dynamic `i18n.t()` calls
- Keep the existing API contracts
- Do not break photo-post or video-post flows
- Prefer progressive enhancement over large rewrites

### Track C — Production Gate Closure (Highest leverage)
Close any gate that is under repository control:
- Record verified TikTok properties as evidence
- Branch protection / ruleset evidence
- Secret scanning cleanliness
- Backup + isolated restore rehearsal (if environment allows)
- Media retention / cleanup job
- Observability (structured logs + basic health metrics)
- Container vulnerability scan / SBOM if CI supports it
- Token encryption key backup procedure documentation

Record remaining items as `BLOCKED_EXTERNAL` or `NOT_TESTED` with clear reasons.

### Track D — Architecture Boundary Reinforcement
- Keep Affiliate Core free of direct TikTok client calls
- Ensure publishing remains provider-neutral in intent
- Document current vs target state of Commerce / Affiliate / Distribution layers
- Do not expand TikTok scope beyond Login Kit + Content Posting API

### Track E — Operational Completeness
- Background cleanup for expired OAuth/browser records and temporary media
- Clear media retention policy implementation
- Improved error classification and user-facing messages (still i18n-aware)
- Health/readiness endpoints that reflect real dependencies

---

## 5. TikTok boundary (strict)

- TikTok remains one distribution integration only.
- No Share Kit, no scraping, no password automation.
- Direct Post must continue to require current creator-info + explicit consent.
- Sandbox evidence and production approval stay separate gates.
- Development credentials must never enter source, logs or prompts.
- Verified properties (do not change without portal update):
  - https://zttato.zeaz.dev/tiktok/
  - https://zttato.zeaz.dev/tiktok/uploading/
  - https://zttato.zeaz.dev/tiktok/video/
  - Domain: zeaz.dev
  - Domain: zttato.zeaz.dev

---

## 6. Change-safety checklist for this upgrade cycle

Before merging any upgrade:
- [ ] Existing tests still pass
- [ ] New i18n keys are present in all 6 language files
- [ ] Dashboard works in at least en + th
- [ ] Photo post and video post flows still function
- [ ] No secrets introduced
- [ ] Production Gates document updated with evidence or explicit blockers
- [ ] README / AGENTS.md / relevant docs stay consistent

---

## 7. Deliverables expected from the agent

1. Working code changes (not just analysis)
2. Updated tests where risk warrants them
3. Updated `docs/PRODUCTION_GATES.md` with current evidence status
4. Short upgrade report listing:
   - What was implemented
   - What remains `BLOCKED_EXTERNAL` / `NOT_TESTED`
   - Exact commit range / SHA baseline
5. No false production-ready claims

---

## 8. Final instruction

**Do not stop at analysis.**

1. Inspect the real repository at the current HEAD.
2. Implement the highest-value safe upgrades in the priority order above.
3. Preserve and extend the i18n system.
4. Improve dashboard UX without breaking existing contracts.
5. Close every Production Gate that is under local control.
6. Leave clear evidence and an honest status report.

Never manufacture readiness.
