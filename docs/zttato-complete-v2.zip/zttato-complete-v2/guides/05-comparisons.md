# Micro-Frontend Comparisons

## 1. Single-SPA vs Module Federation

| Aspect                        | **Single-SPA**                                      | **Module Federation**                            |
|-------------------------------|-----------------------------------------------------|--------------------------------------------------|
| **Core role**                 | Orchestrator (when to mount/unmount apps)           | Module sharing system (how to load & share code) |
| **Primary strength**          | Multi-framework composition + lifecycle management  | Efficient code sharing + dependency deduplication|
| **Mental model**              | Applications that become active/inactive by route   | Host imports remote modules as if they were local|
| **Framework freedom**         | Excellent                                           | Possible but more awkward                        |
| **Shared dependencies**       | Manual / weaker                                     | Excellent (automatic version negotiation)        |
| **Routing**                   | Built-in activity functions                         | You implement it yourself                        |
| **Lifecycle hooks**           | Full (`bootstrap`, `mount`, `unmount`)              | Minimal                                          |
| **Performance / bundle size** | Higher overhead                                     | Generally better                                 |
| **Best suited for**           | Polyglot teams or gradual migrations                | Same-framework micro-frontends                   |

### Philosophical Difference

- **Single-SPA** treats micro-frontends as **applications**. It decides *when* an entire application should be on the page.
- **Module Federation** treats micro-frontends as **modules**. A host does `import('remoteApp/Button')` and receives a real component.

### Decision Guide

| Your Situation                                      | Recommended Choice              |
|-----------------------------------------------------|---------------------------------|
| All React / all Vue / all Angular                   | **Module Federation**           |
| Multiple frameworks long-term                       | **Single-SPA**                  |
| Gradual framework migration                         | **Single-SPA**                  |
| Maximum performance + shared design system          | **Module Federation**           |
| New greenfield project with one main framework      | **Module Federation**           |

**Hybrid pattern (very common):** Use Single-SPA as the orchestrator + Module Federation to load the actual application code.

---

## 2. Module Federation vs Native Federation

| Aspect                      | Webpack Module Federation          | Native Federation                     |
|----------------------------|------------------------------------|---------------------------------------|
| **Foundation**             | Webpack runtime                    | ES Modules + Import Maps              |
| **Bundler lock-in**        | Strong                             | Almost none                           |
| **Build speed (Angular)**  | Slower                             | Much faster (esbuild)                 |
| **Angular 17+ support**    | Works, but not ideal               | Native / first-class                  |
| **SSR / Hydration**        | Possible with effort               | Supported out of the box              |
| **Future-proofing**        | Tied to Webpack ecosystem          | Web standards                         |

**Recommendation (2026):**
- New Angular projects → **Native Federation**
- Existing Webpack MF codebases → stay with Module Federation or migrate gradually
- Multi-framework needs → Single-SPA (optionally + Module/Native Federation)

---

## 3. Three-Way Summary

| Criteria                    | Single-SPA                     | Module Federation              | Native Federation              |
|----------------------------|--------------------------------|--------------------------------|--------------------------------|
| Multi-framework support    | Excellent                      | Possible but awkward           | Possible                       |
| Same-framework performance | Good                           | Best                           | Very good (especially Angular) |
| Shared dependencies        | Manual                         | Automatic                      | Automatic                      |
| Learning curve             | Medium-High                    | Medium                         | Medium                         |
| Bundler lock-in            | None                           | Strong                         | Almost none                    |
| Best for                   | Polyglot / migration           | Same-stack MFEs                | Modern Angular projects        |
