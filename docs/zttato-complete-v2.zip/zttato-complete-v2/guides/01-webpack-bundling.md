# Webpack Bundling — Complete Guide

Webpack is a static **module bundler**. It takes your application’s modules (JS, CSS, images, fonts, etc.), builds a **dependency graph**, and packs everything into one or more optimized **bundles** that browsers (or Node) can load efficiently.

---

## 1. Core Idea

```
Source files  →  Dependency Graph  →  Transformed Modules  →  Bundles (output)
```

1. You declare one or more **entry points**.
2. Webpack recursively finds every `import` / `require`.
3. **Loaders** transform non-JS files into modules.
4. **Plugins** perform broader tasks (minification, HTML generation, asset optimization…).
5. Webpack emits the final files according to the **output** configuration.

---

## 2. Essential Concepts

| Concept | What it does |
|---------|--------------|
| **Entry** | Starting point(s) of the dependency graph |
| **Output** | Where and how the bundles are written to disk |
| **Loaders** | Transform files (e.g. TS → JS, SCSS → CSS, images → URLs) |
| **Plugins** | Perform wider tasks (minification, code splitting, HTML injection, etc.) |
| **Mode** | `development` / `production` / `none` — enables built-in optimizations |
| **Code Splitting** | Break the app into smaller chunks loaded on demand |
| **Tree Shaking** | Remove unused (dead) code in production |
| **Module Federation** | Share modules between independent builds at runtime (micro-frontends) |

---

## 3. Minimal Configuration

```js
// webpack.config.js
const path = require('path');

module.exports = {
  mode: 'production',          // enables minification + tree-shaking
  entry: './src/index.js',     // starting point
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name].[contenthash:8].js',
    clean: true                // wipe dist before each build
  }
};
```

---

## 4. Entry Points

```js
// Single entry
entry: './src/index.js'

// Multiple entries → multiple bundles
entry: {
  app: './src/app.js',
  admin: './src/admin.js'
}

// Array (combined into one chunk)
entry: ['./src/polyfills.js', './src/index.js']
```

---

## 5. Output

```js
output: {
  path: path.resolve(__dirname, 'dist'),
  filename: '[name].[contenthash:8].js',
  chunkFilename: '[name].[contenthash:8].chunk.js',
  assetModuleFilename: 'assets/[hash][ext][query]',
  publicPath: '/',
  clean: true
}
```

Common placeholders: `[name]`, `[contenthash]`, `[id]`, `[hash]`, `[fullhash]`

---

## 6. Loaders

```js
module: {
  rules: [
    {
      test: /\.[jt]sx?$/,
      exclude: /node_modules/,
      use: 'babel-loader'
    },
    {
      test: /\.css$/,
      use: ['style-loader', 'css-loader']
    },
    {
      test: /\.(png|jpg|gif|svg)$/i,
      type: 'asset/resource'
    }
  ]
}
```

---

## 7. Plugins

```js
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

plugins: [
  new HtmlWebpackPlugin({ template: './src/index.html' }),
  new MiniCssExtractPlugin({ filename: '[name].[contenthash].css' }),
]
```

---

## 8. Code Splitting & Optimization

```js
optimization: {
  minimize: true,
  splitChunks: {
    chunks: 'all',
    cacheGroups: {
      vendor: {
        test: /[\\/]node_modules[\\/]/,
        name: 'vendors',
        chunks: 'all'
      }
    }
  },
  runtimeChunk: 'single'
}
```

Dynamic imports create automatic code splitting:

```js
const module = await import('./heavy-feature.js');
```

---

## 9. Development vs Production

| Feature              | `mode: 'development'`      | `mode: 'production'`          |
|----------------------|----------------------------|-------------------------------|
| Minification         | Off                        | On (Terser)                   |
| Tree shaking         | Limited                    | Full                          |
| Source maps          | Fast                       | High quality                  |
| Module / chunk IDs   | Named                      | Deterministic                 |

---

## 10. Modern Alternatives

| Tool            | Relationship to Webpack                  |
|-----------------|------------------------------------------|
| **Vite**        | Uses esbuild + Rollup (much faster dev)  |
| **Rspack**      | Webpack-compatible, written in Rust      |
| **esbuild**     | Extremely fast, limited plugin ecosystem |
| **Rollup**      | Excellent for libraries                  |
| **Parcel**      | Zero-config alternative                  |
