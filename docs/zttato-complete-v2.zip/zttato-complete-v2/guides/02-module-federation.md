# Webpack Module Federation — Deep Dive

Module Federation (introduced in Webpack 5) lets **multiple independent builds** act as a single application at runtime. Each build can **expose** modules and **consume** modules from other builds without rebuilding everything together.

It is the foundation of modern **micro-frontends**, but it is not limited to frontends — it works for any JavaScript modules.

---

## 1. Core Problem It Solves

| Approach | Problem |
|----------|---------|
| Monolith | Single huge build, slow CI, tight coupling |
| npm packages | Version hell, forced rebuilds of consumers |
| iframes | Bad UX, no shared state, styling isolation issues |
| Manual script tags | No dependency resolution, no shared libraries |

**Module Federation** solves this by building each part independently, loading remote modules at runtime, and sharing libraries so they are not duplicated.

---

## 2. Key Concepts

| Term | Meaning |
|------|---------|
| **Host** | The application that consumes remote modules |
| **Remote** | A build that exposes modules for others to use |
| **Container** | The runtime object created by a federated build |
| **Exposed module** | A module made available to other builds |
| **Shared module** | A library that should be shared between builds |
| **Remote entry** | The special file (`remoteEntry.js`) that bootstraps a remote |

A single build can be **both** a host and a remote at the same time.

---

## 3. Basic Configuration

### Remote (exposes modules)

```js
const { ModuleFederationPlugin } = require('webpack').container;
const deps = require('./package.json').dependencies;

module.exports = {
  output: { publicPath: 'auto' },
  plugins: [
    new ModuleFederationPlugin({
      name: 'remoteApp',
      filename: 'remoteEntry.js',
      exposes: {
        './Button': './src/Button',
        './Header': './src/Header',
      },
      shared: {
        react: { singleton: true, requiredVersion: deps.react },
        'react-dom': { singleton: true, requiredVersion: deps['react-dom'] },
      },
    }),
  ],
};
```

### Host (consumes modules)

```js
new ModuleFederationPlugin({
  name: 'hostApp',
  remotes: {
    remoteApp: 'remoteApp@http://localhost:3001/remoteEntry.js',
  },
  shared: {
    react: { singleton: true, requiredVersion: deps.react },
    'react-dom': { singleton: true, requiredVersion: deps['react-dom'] },
  },
})
```

### Using a remote module

```js
const Button = React.lazy(() => import('remoteApp/Button'));

function App() {
  return (
    <React.Suspense fallback="Loading...">
      <Button />
    </React.Suspense>
  );
}
```

---

## 4. Shared Dependencies

```js
shared: {
  react: { singleton: true, requiredVersion: '^18.0.0' },
  lodash: {
    singleton: false,
    requiredVersion: deps.lodash,
    eager: false,
    strictVersion: true,
  },
}
```

| Option | Meaning |
|--------|---------|
| `singleton: true` | Only one instance allowed |
| `requiredVersion` | Version range that must be satisfied |
| `strictVersion` | Throw error on mismatch |
| `eager: true` | Include in the initial chunk |

---

## 5. Advanced Patterns

- **Dynamic Remotes** — resolve remote URL at runtime
- **Bidirectional Federation** — both apps expose and consume
- **TypeScript Support** — generate `.d.ts` files
- **SSR / Next.js** — dedicated packages available
- **Versioning Strategy** — use `requiredVersion` + `singleton`

---

## 6. Common Pitfalls

| Problem | Solution |
|---------|----------|
| Multiple React instances | Always set `singleton: true` |
| Remote not found | Check `publicPath` and CORS |
| Shared module version conflict | Use `strictVersion: true` |
| Large initial load | Avoid `eager: true` for big libs |

---

## 7. When to Use

**Good fit:** Micro-frontends owned by different teams, independently deployable features, large applications that need to scale development, sharing a design system.

**Overkill:** Small single-team applications, simple npm package sharing.
