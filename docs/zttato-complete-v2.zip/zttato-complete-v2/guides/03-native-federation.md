# Native Federation — Deep Dive

**Native Federation** is a modern, bundler-agnostic implementation of the **Module Federation mental model**, built on **web standards** (ES Modules + Import Maps) instead of Webpack-specific runtime code.

It was created primarily by Manfred Steyer and the Angular Architects team because Angular 17+ moved to **esbuild**, while classic Webpack Module Federation was tightly coupled to Webpack.

Official site: https://native-federation.com

---

## 1. Core Idea

| Concept | Native Federation Approach |
|-----------------------|------------------------------------------------------------|
| **Mental model** | Same as Webpack Module Federation (Host, Remote, Shared) |
| **Implementation** | Browser-native (ESM + Import Maps) |
| **Bundler dependency** | None (works with esbuild, Vite, Webpack via adapters) |
| **Runtime** | Standard dynamic `import()` + Import Maps |
| **Goal** | Future-proof micro-frontends that outlive any single bundler |

---

## 2. How It Works

1. Each remote builds and publishes a **`remoteEntry.json`** + ESM bundles.
2. The host loads a **manifest** that points to all remotes.
3. Native Federation generates an **Import Map**.
4. The host does a normal `import('remoteApp/Component')`.
5. Shared dependencies are negotiated by version and loaded only once.

---

## 3. Main Packages (2026)

| Package | Purpose |
|---------------------------------------------|---------------------------------------------|
| `@softarc/native-federation` | Core (framework & bundler agnostic) |
| `@angular-architects/native-federation` | Official Angular adapter (most popular) |
| `@softarc/native-federation-esbuild` | esbuild adapter |
| `@softarc/native-federation-orchestrator` | Runtime orchestrator for non-JS hosts |

---

## 4. Angular Quick Start

```bash
npm i @angular-architects/native-federation -D

ng g @angular-architects/native-federation:init \
  --project mfe1 --port 4201 --type remote

ng g @angular-architects/native-federation:init \
  --project shell --port 4200 --type dynamic-host
```

Configuration (`federation.config.js`):

```js
import { withNativeFederation, shareAll } from '@angular-architects/native-federation/config';

export default withNativeFederation({
  name: 'mfe1',
  exposes: {
    './Component': './src/app/my-component.ts',
    './routes': './src/app/remote.routes.ts',
  },
  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: 'auto',
    }),
  },
});
```

---

## 5. Native Federation vs Webpack Module Federation

| Aspect                      | Webpack Module Federation          | Native Federation                     |
|----------------------------|------------------------------------|---------------------------------------|
| **Foundation**             | Webpack runtime                    | ES Modules + Import Maps              |
| **Bundler lock-in**        | Strong                             | Almost none                           |
| **Build speed (Angular)**  | Slower                             | Much faster (esbuild)                 |
| **Angular 17+ support**    | Works, but not ideal               | Native / first-class                  |
| **SSR / Hydration**        | Possible with effort               | Supported out of the box              |
| **API familiarity**        | Original                           | Intentionally almost identical        |
| **Future-proofing**        | Tied to Webpack ecosystem          | Web standards                         |

---

## 6. When to Choose Native Federation

**Strongly recommended when:**
- You are on **Angular 17+**
- You want the fastest possible builds
- You prefer web standards over bundler-specific runtimes
- You value long-term maintainability

**Still better with classic Module Federation when:**
- You have a large existing Webpack MF codebase
- You need maximum multi-framework flexibility right now
