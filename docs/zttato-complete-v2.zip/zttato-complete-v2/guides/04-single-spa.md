# Single-SPA Micro-Frontends — Complete Exploration

**single-spa** is a lightweight (~5 kb gzipped) JavaScript framework for building **micro-frontends**. It acts as an **orchestrator** that decides *when* to mount and unmount independent applications based on the current URL, while remaining completely framework-agnostic.

Official site: https://single-spa.js.org

---

## 1. Core Philosophy

| Principle | Meaning |
|-----------------------|-----------------------------------------------------------------------------|
| **Framework agnostic** | React, Angular, Vue, Svelte, AngularJS, Ember, plain JS — all can coexist |
| **Independent deploy** | Each micro-frontend has its own repo, build, and deployment pipeline |
| **Lifecycle control** | single-spa manages bootstrap → mount → unmount |
| **Routing-driven** | Applications become active/inactive based on URL activity functions |
| **No page refresh** | Switching between micro-frontends feels like a single-page application |

---

## 2. Three Types of Micro-Frontends

| Type | Routing | Renders UI? | Lifecycle | Best Used For |
|------------------|------------------|-------------|----------------------------------|---------------------------------------------|
| **Application** | Yes (multiple routes) | Yes | Managed by single-spa | Main building blocks of your product |
| **Parcel** | No | Yes | Manually controlled | Reusable UI pieces across frameworks |
| **Utility** | No | Optional | None (just exports an API) | Shared logic, design system, auth, API clients |

---

## 3. Architecture Overview

```
Root Config (HTML + single-spa registration + import maps)
  ├── registerApplication('navbar', ...)
  ├── registerApplication('dashboard', ...)
  └── registerApplication('settings', ...)

Navbar (React)     Dashboard (Vue)     Settings (Angular)
```

---

## 4. Basic Setup Example

```js
import { registerApplication, start } from 'single-spa';

registerApplication({
  name: '@org/navbar',
  app: () => System.import('@org/navbar'),
  activeWhen: ['/'],
});

registerApplication({
  name: '@org/dashboard',
  app: () => System.import('@org/dashboard'),
  activeWhen: ['/dashboard'],
});

start();
```

Each application exports lifecycles:

```js
import singleSpaReact from 'single-spa-react';
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

const lifecycles = singleSpaReact({
  React,
  ReactDOM,
  rootComponent: App,
});

export const { bootstrap, mount, unmount } = lifecycles;
```

---

## 5. Key Features

| Feature | Description |
|---------------------------|-----------------------------------------------------------------------------|
| **Activity Functions** | Decide when an application is active |
| **single-spa-layout** | Declarative HTML-like layout engine |
| **Import Maps** | Modern way to map module names to URLs |
| **SSR Support** | Possible with single-spa-layout |
| **CSS Management** | `single-spa-css` helper |
| **Parcels** | Cross-framework component sharing |
| **Utilities** | Shared services without UI |

---

## 6. Strengths & Weaknesses

**Strengths:** Best-in-class multi-framework support, excellent for gradual migrations, clear separation of concerns, mature ecosystem.

**Weaknesses:** Higher runtime overhead, shared dependencies require more manual work, steeper learning curve for orchestration concepts.

---

## 7. When to Choose Single-SPA

**Strong fit:** Multiple frameworks on the same page, migrating from a legacy stack, teams want maximum technological freedom, strong application-level lifecycle control.

**Weaker fit:** All teams already use the same modern framework, maximum performance is critical.
